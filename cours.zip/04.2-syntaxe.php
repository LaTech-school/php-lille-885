<?php 
// Ce fichier ne contient que du PHP
//  La balise de fermeture est facultative

for ($i= 0; $i<10; $i++)
{
    echo $i . "<br>";
}
