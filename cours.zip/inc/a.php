<?php 

echo "fichier A.php<br>";